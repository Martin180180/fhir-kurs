# fhir.education.kursig#0.1.0: MK FHIR-utbildning – Kurs-IG

## Pages

* [Hem](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [MK EducationEncounter profil FSH](StructureDefinition-EducationEncounter.md)
* [Education Patient](StructureDefinition-EducationPatient.md)

### ImplementationGuides

* [MK FHIR-utbildning – Kurs-IG](index.md)

### Examples

* [patient-tolvan (Patient)](Patient-patient-tolvan.md)
